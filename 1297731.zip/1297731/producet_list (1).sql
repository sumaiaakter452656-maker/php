-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 04, 2026 at 05:11 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pwad731`
--

-- --------------------------------------------------------

--
-- Table structure for table `producet_list`
--

CREATE TABLE `producet_list` (
  `id` int(15) NOT NULL,
  `Produect_name` varchar(100) NOT NULL,
  `Category` varchar(50) NOT NULL,
  `Descrivtion` varchar(500) NOT NULL,
  `price` int(12) NOT NULL,
  `Quantity` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `producet_list`
--

INSERT INTO `producet_list` (`id`, `Produect_name`, `Category`, `Descrivtion`, `price`, `Quantity`) VALUES
(1, 'shirt', '', 'tfgghydryg', 0, 50),
(2, 'er', '', 'sedr', 0, -2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `producet_list`
--
ALTER TABLE `producet_list`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `producet_list`
--
ALTER TABLE `producet_list`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
